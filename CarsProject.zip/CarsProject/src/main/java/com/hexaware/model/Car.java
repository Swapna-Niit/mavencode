package com.hexaware.model;

public class Car {
    
    private int Id;
    private String Name;
    private int Price;

    public Car(int i, String Name, int Price) {
        this.Id = i;
        this.Name = Name;
        this.Price = Price;
    }

    public Car() {
		// TODO Auto-generated constructor stub
	}

	public int getId() {
        return Id;
    }

    public void setId(int Id) {
        this.Id = Id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public int getPrice() {
        return Price;
    }

    public void setPrice(int Price) {
        this.Price = Price;
    }

    @Override
    public String toString() {
        return "Car{" + "Id=" + Id + ", Name=" + Name + ", Price=" + Price + '}';
    }
}