package com.hexaware.util;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.hexaware.factory.CarFactory;
import com.hexaware.model.Car;

@Path("/car")
public class CarRest {
  /**
   * Returns Menu details.
   * @return the menu details
   */
  @GET
  @Produces(MediaType.APPLICATION_JSON)
  public final Car[] listMenu() {
    final Car[] cars = CarFactory.showMenu();
    return cars;
  }

}