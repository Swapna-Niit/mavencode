package com.hexaware.factory;

import java.util.List;

import com.hexaware.model.Car;

public class CarFactory {
 
    protected CarFactory() {

  }

  private static CarDAO dao() {
    DbConnection db = new DbConnection();
    return db.getConnect().onDemand(CarDAO.class);
  }
 
  public static Car[] showMenu() {
    List<Car> car = dao().show();
    return car.toArray(new Car[car.size()]);
  }
}
