package com.hexaware.factory;

import org.skife.jdbi.v2.sqlobject.SqlQuery;
import org.skife.jdbi.v2.sqlobject.customizers.Mapper;
import java.util.List;
import com.hexaware.model.Car;
import com.hexaware.persistance.CarMapper;

public interface CarDAO {

  @SqlQuery("Select * from Cars")
    @Mapper(CarMapper.class)
    List<Car> show();
}
