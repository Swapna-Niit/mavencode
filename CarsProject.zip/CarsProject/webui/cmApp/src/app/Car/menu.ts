export class Menu {
  constructor( public carId: int,
              public carName:string, 
              public Price:int)
              {}
}
